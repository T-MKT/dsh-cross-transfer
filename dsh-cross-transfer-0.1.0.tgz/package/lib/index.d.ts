import z from "@deepseek-ai/schemastery";
import { Context, Service } from "@deepseek-ai/cordis";
import { WebSocket } from "ws";
import { IncomingMessage } from "http";

//#region src/chat.d.ts
interface ChatConfig {
  maxHistoryPerRoom: number;
  maxMessageLength: number;
}
interface ChatMessage {
  messageId: string;
  roomId: string;
  senderDeviceId: string;
  senderDeviceName: string;
  senderSessionId: string;
  content: string;
  type: 'text' | 'system' | 'file' | 'code';
  metadata?: Record<string, unknown>;
  timestamp: number;
  edited?: boolean;
  replyTo?: string;
}
interface ChatRoom {
  roomId: string;
  name: string;
  createdAt: number;
  participantCount: number;
  lastMessageAt: number;
}
interface ChatEvents {
  'message': [message: ChatMessage];
  'message-edited': [message: ChatMessage];
  'message-deleted': [messageId: string, roomId: string];
  'room-created': [room: ChatRoom];
  'user-joined': [roomId: string, deviceId: string, deviceName: string];
  'user-left': [roomId: string, deviceId: string];
  'typing': [roomId: string, deviceId: string, deviceName: string, isTyping: boolean];
}
declare class ChatService extends Service {
  private config;
  private rooms;
  private userRooms;
  private emitter;
  constructor(ctx: Context);
  on<K extends keyof ChatEvents>(event: K, listener: (...args: ChatEvents[K]) => void): () => void;
  off<K extends keyof ChatEvents>(event: K, listener: (...args: ChatEvents[K]) => void): void;
  emit<K extends keyof ChatEvents>(event: K, ...args: ChatEvents[K]): void;
  once<K extends keyof ChatEvents>(event: K, listener: (...args: ChatEvents[K]) => void): () => void;
  initialize(config?: Partial<ChatConfig>): void;
  createRoom(roomId: string, name: string): ChatRoom;
  getRoom(roomId: string): ChatRoom | undefined;
  getRooms(): ChatRoom[];
  joinRoom(deviceId: string, deviceName: string, roomId?: string): boolean;
  leaveRoom(deviceId: string, deviceName: string, roomId: string): boolean;
  sendMessage(data: {
    roomId: string;
    senderDeviceId: string;
    senderDeviceName: string;
    senderSessionId: string;
    content: string;
    type?: 'text' | 'system' | 'file' | 'code';
    metadata?: Record<string, unknown>;
    replyTo?: string;
  }): ChatMessage;
  editMessage(messageId: string, roomId: string, newContent: string, deviceId: string): ChatMessage | null;
  deleteMessage(messageId: string, roomId: string, deviceId: string): boolean;
  getHistory(roomId: string, limit?: number, before?: number): ChatMessage[];
  setTyping(roomId: string, deviceId: string, deviceName: string, isTyping: boolean): void;
  getParticipants(roomId: string): string[];
  getUserRooms(deviceId: string): string[];
  private generateMessageId;
  shutdown(): void;
}
//# sourceMappingURL=chat.d.ts.map
//#endregion
//#region src/rooms.d.ts
type RoomRole = 'owner' | 'member';
/** 房号：4~12 位纯数字字符串 */
type RoomId = string;
/** 设备身份凭据（256-bit hex）。客户端自存、服务端只认它，deviceId 由它派生 */
type DeviceSecret = string;
/**
 * 房间的公开投影。不含 sessionId、不含票据、不含任何凭据。
 * ownerDeviceId 在对外投影里必须脱敏（见 maskDeviceId），因为它不是凭据但也不该被枚举。
 */
interface RoomInfo {
  roomId: RoomId;
  name: string;
  /** 脱敏房主设备 id（前 4 + '…' + 后 4）。用于 UI 判断「我是不是房主」，不是授权依据 */
  ownerDeviceId: string;
  /** 房主当前是否有活会话 */
  ownerOnline: boolean;
  createdAt: number;
  lastActivityAt: number;
  /** 成员行数，含离线但保留席位的成员 */
  memberCount: number;
  maxMembers: number;
  locked: boolean;
  discoverable: boolean;
}
/** 成员视图。deviceId 同样脱敏；sessionIds 集合永不外泄，只暴露计数与在线位。 */
interface RoomMember {
  deviceId: string;
  deviceName: string;
  role: RoomRole;
  joinedAt: number;
  sessionCount: number;
  online: boolean;
}
/** 票据的服务端记录 */
interface RoomTicket {
  ticket: string;
  roomId: RoomId;
  deviceId: string;
  role: RoomRole;
  issuedAt: number;
  expiresAt: number;
}
type RoomCloseReason = 'closed-by-owner' | 'idle-timeout' | 'owner-left';
/** 只描述非惩罚性离开；被踢走 member-kicked 事件 */
type RoomLeaveReason = 'left' | 'disconnected';
interface DeviceCredential {
  deviceSecret: string;
  deviceId: string;
  deviceName: string;
  createdAt: number;
  lastSeenAt: number;
}
interface DeviceRegisterRequest {
  /** 首次登记时省略；服务端铸一个新 secret 并返回 */
  deviceSecret?: DeviceSecret;
  deviceName?: string;
}
interface DeviceRegisterResult {
  deviceId: string;
  deviceSecret: DeviceSecret;
  deviceName: string;
  /** 与 deviceId+tokenSecret 对应的连接 token，免再调一次 /token */
  token: string;
}
interface RoomConfig {
  maxRooms: number;
  maxRoomsPerDevice: number;
  maxMembersPerRoom: number;
  roomCodeLength: number;
  minPasswordLength: number;
  maxJoinAttempts: number;
  joinAttemptWindowMs: number;
  joinLockoutMs: number;
  ticketTtlMs: number;
  idleTtlMs: number;
  closeWhenOwnerLeaves: boolean;
  discoverableByDefault: boolean;
  allowRoomList: boolean;
}
interface RoomEvents {
  'room-created': [room: RoomInfo, memberSessionIds: string[]];
  'room-closed': [roomId: RoomId, reason: RoomCloseReason, memberSessionIds: string[]];
  'member-joined': [roomId: RoomId, member: RoomMember, memberSessionIds: string[]];
  'member-left': [roomId: RoomId, deviceId: string, reason: RoomLeaveReason, memberSessionIds: string[]];
  'member-kicked': [roomId: RoomId, deviceId: string, kickedByDeviceId: string, targetSessionIds: string[], memberSessionIds: string[]];
  'owner-changed': [roomId: RoomId, newOwnerDeviceId: string, memberSessionIds: string[]];
  'password-changed': [roomId: RoomId, memberSessionIds: string[]];
  'lock-changed': [roomId: RoomId, locked: boolean, memberSessionIds: string[]];
}
interface CreateRoomRequest {
  roomId?: RoomId;
  name?: string;
  password: string;
  maxMembers?: number;
  discoverable?: boolean;
  deviceId: string;
  deviceName: string;
  sessionId?: string;
  remoteAddress?: string;
}
interface JoinRoomRequest {
  roomId: RoomId;
  password: string;
  deviceId: string;
  deviceName: string;
  sessionId?: string;
  remoteAddress?: string;
}
interface RoomJoinResult {
  room: RoomInfo;
  member: RoomMember;
  ticket: RoomTicket;
}
interface RoomLeaveResult {
  roomId: RoomId;
  deviceId: string;
  /** 成员行是否被移除（显式退房 true；仅会话断开 false） */
  removed: boolean;
  /** closeWhenOwnerLeaves=true 且房主退房 */
  closed: boolean;
  newOwnerDeviceId?: string;
}
/** deviceId = sha256('xfer-device:' + secret).slice(0, 16)。secret 是 32 字节 hex。 */

/** 密码哈希参数快照，随每条哈希一起存，便于将来升级参数而不作废旧房间。 */
interface ScryptParams {
  N: number;
  r: number;
  p: number;
}
declare class RoomService extends Service {
  private config;
  private scryptParams;
  private rooms;
  private credentials;
  private tickets;
  private createReservations;
  private sessionRooms;
  private closedRooms;
  private failureWindows;
  private lockouts;
  private sweepTimer;
  private emitter;
  constructor(ctx: Context);
  on<K extends keyof RoomEvents>(event: K, listener: (...args: RoomEvents[K]) => void): () => void;
  off<K extends keyof RoomEvents>(event: K, listener: (...args: RoomEvents[K]) => void): void;
  emit<K extends keyof RoomEvents>(event: K, ...args: RoomEvents[K]): void;
  once<K extends keyof RoomEvents>(event: K, listener: (...args: RoomEvents[K]) => void): () => void;
  initialize(config?: Partial<RoomConfig>): void;
  shutdown(): void;
  /** 当前配置的浅拷贝，只读用。 */
  getConfig(): RoomConfig;
  /**
   * 登记或凭已有 secret 取回身份。
   * 未登记 + 无 secret → invalid-device（调用方应先走 /devices/register）。
   */
  registerDevice(request: DeviceRegisterRequest): DeviceRegisterResult;
  /** 解析并刷新 lastSeenAt；未登记 → invalid-device */
  authenticateDevice(deviceSecret: DeviceSecret | undefined, deviceId: string): DeviceCredential;
  /**
   * 该 deviceId 是否已被登记为凭据。凭据表以 deviceSecret 为键，这里按值扫一遍：
   * 只在 legacy token 回落这类低频路径上调用。legacy 回落必须拒掉已登记的
   * deviceId——已登记 id 是别人的身份，无凭据给它铸连接 token 就等于冒充
   * 已登记成员/房主（deviceId 本身在系统内不是秘密，可经设备列表或广播枚举到）。
   */
  hasDeviceId(deviceId: string): boolean;
  private normalizeDeviceName;
  private evictCredentials;
  createRoom(request: CreateRoomRequest): Promise<RoomJoinResult>;
  joinRoom(request: JoinRoomRequest): Promise<RoomJoinResult>;
  /** 设备级显式退房：移除成员行与该设备全部会话（含同设备其它标签页） */
  leaveRoom(roomId: RoomId, deviceId: string): Promise<RoomLeaveResult>;
  /** 关房（仅房主） */
  closeRoom(roomId: RoomId, actorDeviceId: string): Promise<void>;
  /**
   * 踢人（仅房主；不能踢自己）。移除成员行 + 摘掉其全部会话 + 清 sessionRooms + 吊票据。
   * 三者缺一：行还在就会被快速通道无密码放回，会话还挂就会被 isSessionMember 放行。
   */
  kickMember(roomId: RoomId, actorDeviceId: string, targetDeviceId: string): Promise<void>;
  changePassword(roomId: RoomId, actorDeviceId: string, password: string): Promise<void>;
  setLocked(roomId: RoomId, actorDeviceId: string, locked: boolean): Promise<void>;
  /** 可发现房间的公开投影。关闭房间列表时一律为空（fail-closed）。 */
  listRooms(): RoomInfo[];
  getRoomInfo(roomId: RoomId, actorDeviceId: string): RoomInfo;
  /**
   * 成员列表。只有该房成员能读；deviceId 一律脱敏（契约 §1.1：成员视图不分视角）。
   * 真实 id 只经 user-joined / member-kicked 等推送语义流转，不从列表反查——
   * 否则房主视角就成了把真 id 集中放在一个可读响应里的泄漏点。
   */
  getMembers(roomId: RoomId, actorDeviceId: string): RoomMember[];
  /** 含建房占位（见并发与原子性约定） */
  hasRoom(roomId: RoomId): boolean;
  /** 含建房占位（每间在途建房只算一次，见 occupiedRoomCount） */
  getRoomCount(): number;
  roomCountForDevice(deviceId: string): number;
  authenticate(ticket: string, roomId: RoomId): RoomTicket;
  /** 解析 Authorization: Bearer <ticket 或 deviceSecret>。两者都不认时 → invalid-ticket。 */
  authenticateBearer(authorization: string | undefined, roomId?: RoomId): {
    ticket?: RoomTicket;
    credential?: DeviceCredential;
  };
  isMember(roomId: RoomId, deviceId: string): boolean;
  isOwner(roomId: RoomId, deviceId: string): boolean;
  isSessionMember(roomId: RoomId, deviceId: string, sessionId: string): boolean;
  getMemberSessionIds(roomId: RoomId): string[];
  touch(roomId: RoomId): void;
  /**
   * 会话断开：摘掉会话，保留席位（online=false）。返回受影响的房间。
   * 不吊销票据：契约 §1.10 的吊销清单只有显式退房/被踢/关房/改密/回收，断线不在其中；
   * 票据按 (roomId, deviceId) 记账不分 会话，这里若顺手吊销，同设备仍在线会话的
   * 房间凭据会被一次标签页关闭连带作废（test/rooms-limits.test.ts 多会话票据用例）。
   */
  dropSession(sessionId: string, deviceId: string): RoomId[];
  /** 一次主动清扫：过期票据 / 墓碑 / 占位 / 凭据 + 空闲回收。测试可手动调。 */
  sweep(now?: number): void;
  /** 仅供测试提速：调低 scrypt 成本。生产路径不碰它。 */
  setScryptParams(params: Partial<ScryptParams>): void;
  private assertRoomId;
  private assertCustomRoomId;
  private assertPassword;
  private normalizeMaxMembers;
  private normalizeRoomName;
  private pickRandomRoomId;
  private hashPassword;
  private verifyPassword;
  private issueTicket;
  private revokeTickets;
  private revokeTicketsFor;
  private ticketsForDevice;
  private attachSession;
  /** 摘掉某设备的全部会话（含 sessionRooms 索引），但保留成员行。 */
  private detachDeviceSessions;
  private refreshCounts;
  private memberSessionIds;
  private transferOwnership;
  private closeRoomInternal;
  private ownedRoomCount;
  /**
   * 全局房间占用数 = 已建成的房间 + 在途占位。占位 record 会同时写进 rooms
   * （passwordHash=null）与 createReservations 两张表，直接把两个 size 相加会把
   * 同一间在途建房算两次，并发建房在还有一半名额时就会被误拒
   * （test/rooms-limits.test.ts「并发建房在还有名额时不得被误拒」）。
   */
  private occupiedRoomCount;
  private pruneReservations;
  private pruneClosedRooms;
  private visibleRooms;
  private requireVisibleRoom;
  private projectRoom;
  private projectMember;
  private assertNotLocked;
  private recordFailure;
  /**
   * 清失败计数与锁定。'all' 用于「刚验证过密码/刚建成房间」的场景，设备键与
   * 共享 ip 键一起清（test/rooms.test.ts「成功进房也会清掉该 IP 的失败计数」）；
   * 'device-only' 用于成员快速通道——它没验证任何凭据之外的东西，共享的
   * ip:<roomId>:<addr> 桶属于同 IP 的所有设备，不能被一次免密回房清掉。
   */
  private clearFailures;
  private rateLimitKeys;
  private runMaintenance;
  private reapIdleRooms;
}
//#endregion
//#region src/ws-server.d.ts
interface WSServerConfig {
  path: string;
  tokenSecret: string;
  maxFileSize: number;
  chunkSize: number;
}
interface WSSession {
  sessionId: string;
  deviceId: string;
  deviceName: string;
  connectedAt: number;
  lastActiveAt: number;
  socket: WebSocket;
  capabilities: Set<string>;
  authenticated: boolean;
  /** 远端地址；用于按 IP 限流。必须由 handleConnection 赋值 */
  remoteAddress?: string;
}
/**
 * The public shape of a session: everything above except the socket, which is
 * never handed out (the server service owns it, not a caller), and except the
 * remote address, which is peer topology rather than session state.
 */
type WSSessionSummary = Omit<WSSession, 'socket' | 'capabilities' | 'remoteAddress'> & {
  /** Capabilities as a JSON-safe array; the live session holds a Set. */
  capabilities: string[];
};
interface WSMessage {
  type: string;
  sessionId?: string;
  deviceId?: string;
  targetDeviceId?: string;
  payload: unknown;
  messageId?: string;
}
/**
 * The room gate owns every message that carries room semantics: room lifecycle,
 * room-scoped chat, and any custom type whose payload names a room. It is a port
 * so src/ws-server.ts never depends on the room implementation.
 */
interface RoomGate {
  /** Non-null reply means "answer the requesting session"; null means the gate already broadcast. */
  handle(session: WSSession, message: WSMessage, server: WSServer): Promise<RoomGateReply | null>;
  onSessionClosed(session: WSSession): void;
}
interface RoomGateReply {
  type: string;
  payload: unknown;
}
interface WSServerEvents {
  connection: [session: WSSession];
  disconnection: [sessionId: string, reason: string];
  message: [session: WSSession, message: WSMessage];
  deviceConnected: [device: DeviceInfo$1];
  deviceDisconnected: [deviceId: string];
  error: [error: Error, session?: WSSession];
}
interface DeviceInfo$1 {
  deviceId: string;
  deviceName: string;
  connectedAt: number;
  lastActiveAt: number;
  sessionCount: number;
  capabilities: string[];
}
declare class WSServer extends Service {
  private wss;
  private config;
  private sessions;
  private deviceRegistry;
  private messageHandlers;
  private pendingRequests;
  private roomGate;
  private emitter;
  constructor(ctx: Context);
  on<K extends keyof WSServerEvents>(event: K, listener: (...args: WSServerEvents[K]) => void): () => void;
  off<K extends keyof WSServerEvents>(event: K, listener: (...args: WSServerEvents[K]) => void): void;
  emit<K extends keyof WSServerEvents>(event: K, ...args: WSServerEvents[K]): void;
  once<K extends keyof WSServerEvents>(event: K, listener: (...args: WSServerEvents[K]) => void): () => void;
  initialize(config: WSServerConfig): void;
  handleUpgrade(req: IncomingMessage, socket: any, head: Buffer): void;
  private handleConnection;
  private handleMessage;
  /**
   * A message carries room semantics when its type is room-scoped by name, or
   * when its payload names a room. The payload arm exists because a client
   * cannot be trusted to stay inside the documented type list: any custom type
   * that mentions a roomId would otherwise fall through to broadcastToAll.
   */
  isRoomScoped(message: WSMessage): boolean;
  private handleRoomScoped;
  /** 唯一的错误帧来源，保证 messageId 回显规则只有一处实现。 */
  private sendRoomError;
  private handleDisconnection;
  private registerDefaultHandlers;
  onMessage(type: string, handler: (session: WSSession, message: WSMessage) => Promise<void>): void;
  /** 只在 src/index.ts 调用：唯一的门禁安装点。 */
  setRoomGate(gate: RoomGate | null): void;
  getRoomGate(): RoomGate | null;
  sendToSession(sessionId: string, message: WSMessage): boolean;
  broadcastToDevice(deviceId: string, message: WSMessage, excludeSessionId?: string): number;
  broadcastToAll(message: WSMessage, excludeSessionId?: string): number;
  /**
   * Deliver to an explicit recipient set. Room delivery goes through here
   * because only the room gate knows who is currently in the room.
   * @returns how many sessions the frame actually reached.
   */
  broadcastToSessions(sessionIds: Iterable<string>, message: WSMessage, excludeSessionId?: string): number;
  request(sessionId: string, message: WSMessage, timeoutMs?: number): Promise<unknown>;
  getDevices(): DeviceInfo$1[];
  /** Session summaries: the socket itself never leaves this service. */
  getSessions(): WSSessionSummary[];
  getSession(sessionId: string): WSSession | undefined;
  getDeviceSessions(deviceId: string): WSSession[];
  private generateSessionId;
  private generateDeviceId;
  private validateToken;
  shutdown(): void;
}
//# sourceMappingURL=ws-server.d.ts.map
//#endregion
//#region src/index.d.ts
/** Cordis plugin name. */
declare const name = "cross-transfer";
/** The route carrier this plugin mounts onto. */
declare const inject: string[];
interface CrossTransferConfig {
  /** Absolute route prefix, no trailing slash. */
  path: string;
  /** Shared secret for device tokens; generated per boot when omitted. */
  tokenSecret?: string;
  maxFileSize: number;
  chunkSize: number;
  /** 房间能力配置；schema 给每一项都配了默认值，旧配置不带 rooms 也能启动。 */
  rooms: RoomConfig;
}
interface DeviceInfo {
  deviceId: string;
  deviceName: string;
  connectedAt: number;
  lastActiveAt: number;
  sessionCount: number;
  capabilities: string[];
}
interface SessionInfo {
  sessionId: string;
  deviceId: string;
  deviceName: string;
  connectedAt: number;
  lastActiveAt: number;
}
/** Validated plugin configuration. */
declare const Config: z<Schemastery.ObjectS<NoInfer<{
  path: z<string, string, "defined">;
  tokenSecret: z<string, string, "plain">;
  maxFileSize: z<number, number, "defined">;
  chunkSize: z<number, number, "defined">;
  rooms: z<Schemastery.ObjectS<NoInfer<{
    maxRooms: z<number, number, "defined">;
    maxRoomsPerDevice: z<number, number, "defined">;
    maxMembersPerRoom: z<number, number, "defined">;
    roomCodeLength: z<number, number, "defined">;
    minPasswordLength: z<number, number, "defined">;
    maxJoinAttempts: z<number, number, "defined">;
    joinAttemptWindowMs: z<number, number, "defined">;
    joinLockoutMs: z<number, number, "defined">;
    ticketTtlMs: z<number, number, "defined">;
    idleTtlMs: z<number, number, "defined">;
    closeWhenOwnerLeaves: z<boolean, boolean, "defined">;
    discoverableByDefault: z<boolean, boolean, "defined">;
    allowRoomList: z<boolean, boolean, "defined">;
  }>>, Schemastery.ObjectT<NoInfer<{
    maxRooms: z<number, number, "defined">;
    maxRoomsPerDevice: z<number, number, "defined">;
    maxMembersPerRoom: z<number, number, "defined">;
    roomCodeLength: z<number, number, "defined">;
    minPasswordLength: z<number, number, "defined">;
    maxJoinAttempts: z<number, number, "defined">;
    joinAttemptWindowMs: z<number, number, "defined">;
    joinLockoutMs: z<number, number, "defined">;
    ticketTtlMs: z<number, number, "defined">;
    idleTtlMs: z<number, number, "defined">;
    closeWhenOwnerLeaves: z<boolean, boolean, "defined">;
    discoverableByDefault: z<boolean, boolean, "defined">;
    allowRoomList: z<boolean, boolean, "defined">;
  }>>, "defined">;
}>>, Schemastery.ObjectT<NoInfer<{
  path: z<string, string, "defined">;
  tokenSecret: z<string, string, "plain">;
  maxFileSize: z<number, number, "defined">;
  chunkSize: z<number, number, "defined">;
  rooms: z<Schemastery.ObjectS<NoInfer<{
    maxRooms: z<number, number, "defined">;
    maxRoomsPerDevice: z<number, number, "defined">;
    maxMembersPerRoom: z<number, number, "defined">;
    roomCodeLength: z<number, number, "defined">;
    minPasswordLength: z<number, number, "defined">;
    maxJoinAttempts: z<number, number, "defined">;
    joinAttemptWindowMs: z<number, number, "defined">;
    joinLockoutMs: z<number, number, "defined">;
    ticketTtlMs: z<number, number, "defined">;
    idleTtlMs: z<number, number, "defined">;
    closeWhenOwnerLeaves: z<boolean, boolean, "defined">;
    discoverableByDefault: z<boolean, boolean, "defined">;
    allowRoomList: z<boolean, boolean, "defined">;
  }>>, Schemastery.ObjectT<NoInfer<{
    maxRooms: z<number, number, "defined">;
    maxRoomsPerDevice: z<number, number, "defined">;
    maxMembersPerRoom: z<number, number, "defined">;
    roomCodeLength: z<number, number, "defined">;
    minPasswordLength: z<number, number, "defined">;
    maxJoinAttempts: z<number, number, "defined">;
    joinAttemptWindowMs: z<number, number, "defined">;
    joinLockoutMs: z<number, number, "defined">;
    ticketTtlMs: z<number, number, "defined">;
    idleTtlMs: z<number, number, "defined">;
    closeWhenOwnerLeaves: z<boolean, boolean, "defined">;
    discoverableByDefault: z<boolean, boolean, "defined">;
    allowRoomList: z<boolean, boolean, "defined">;
  }>>, "defined">;
}>>, "plain">;
/**
 * 房间 WS 面的门禁：所有 room-* 与房间语义消息（chat-message / typing 等）都由它裁决。
 *
 * 它按契约本该落在独立的 src/room-gateway.ts；本单元只允许改三个文件，
 * 所以随宿主接线一起放在这里。构造只订阅事件（广播 + chat 桥接），
 * 不调用 server.setRoomGate —— 安装点在 apply() 里，测试里也各自显式安装。
 */
declare class RoomGateway implements RoomGate {
  private readonly ctx;
  private readonly rooms;
  private readonly chat;
  private readonly server;
  private readonly offEvents;
  /** 已证明持有 deviceSecret 的设备（真 id）。建房/进房快速通道的前置条件。 */
  private readonly provenDevices;
  /** 脱敏 id → 真 id。member-joined 事件只带脱敏 id，user-joined 推送需要真 id。 */
  private readonly maskedIndex;
  constructor(ctx: Context, rooms: RoomService, chat: ChatService, server: WSServer);
  /** REST 面验证过 deviceSecret 之后登记：这个真 deviceId 由此获得进房资格。 */
  proveDevice(deviceId: string): void;
  handle(session: WSSession, message: WSMessage): Promise<RoomGateReply | null>;
  onSessionClosed(session: WSSession): void;
  /** 幂等：执行全部退订函数并清空数组。 */
  dispose(): void;
  private subscribe;
  private ensureChatRoom;
  private assertObject;
  private assertRoomId;
  /**
   * 快速通道的前置条件：这个 deviceId 必须由已登记的 deviceSecret 派生。
   * WS 连接的 token 只证明「会算 sha256」，legacy /token 回落能让自报 deviceId
   * 拿到 token，所以建房/进房必须再看一眼 REST 面登记过的凭据。
   */
  private requireProvenDevice;
  private requireSessionMember;
  private handleRoomCreate;
  private handleRoomJoin;
  private handleRoomLeave;
  private handleRoomClose;
  private handleRoomKick;
  private handleRoomPassword;
  private handleRoomLock;
  private handleRoomList;
  private handleRoomMembers;
  private handleChatMessage;
  private handleChatHistory;
  private handleTyping;
}
/**
 * Mount the WebSocket carrier and the REST surface.
 * @param ctx - plugin context carrying the `webServer` service.
 * @param config - validated plugin configuration.
 */
declare function apply(ctx: Context, config: CrossTransferConfig): void;
declare const _default: {
  name: string;
  inject: string[];
  Config: z<Schemastery.ObjectS<NoInfer<{
    path: z<string, string, "defined">;
    tokenSecret: z<string, string, "plain">;
    maxFileSize: z<number, number, "defined">;
    chunkSize: z<number, number, "defined">;
    rooms: z<Schemastery.ObjectS<NoInfer<{
      maxRooms: z<number, number, "defined">;
      maxRoomsPerDevice: z<number, number, "defined">;
      maxMembersPerRoom: z<number, number, "defined">;
      roomCodeLength: z<number, number, "defined">;
      minPasswordLength: z<number, number, "defined">;
      maxJoinAttempts: z<number, number, "defined">;
      joinAttemptWindowMs: z<number, number, "defined">;
      joinLockoutMs: z<number, number, "defined">;
      ticketTtlMs: z<number, number, "defined">;
      idleTtlMs: z<number, number, "defined">;
      closeWhenOwnerLeaves: z<boolean, boolean, "defined">;
      discoverableByDefault: z<boolean, boolean, "defined">;
      allowRoomList: z<boolean, boolean, "defined">;
    }>>, Schemastery.ObjectT<NoInfer<{
      maxRooms: z<number, number, "defined">;
      maxRoomsPerDevice: z<number, number, "defined">;
      maxMembersPerRoom: z<number, number, "defined">;
      roomCodeLength: z<number, number, "defined">;
      minPasswordLength: z<number, number, "defined">;
      maxJoinAttempts: z<number, number, "defined">;
      joinAttemptWindowMs: z<number, number, "defined">;
      joinLockoutMs: z<number, number, "defined">;
      ticketTtlMs: z<number, number, "defined">;
      idleTtlMs: z<number, number, "defined">;
      closeWhenOwnerLeaves: z<boolean, boolean, "defined">;
      discoverableByDefault: z<boolean, boolean, "defined">;
      allowRoomList: z<boolean, boolean, "defined">;
    }>>, "defined">;
  }>>, Schemastery.ObjectT<NoInfer<{
    path: z<string, string, "defined">;
    tokenSecret: z<string, string, "plain">;
    maxFileSize: z<number, number, "defined">;
    chunkSize: z<number, number, "defined">;
    rooms: z<Schemastery.ObjectS<NoInfer<{
      maxRooms: z<number, number, "defined">;
      maxRoomsPerDevice: z<number, number, "defined">;
      maxMembersPerRoom: z<number, number, "defined">;
      roomCodeLength: z<number, number, "defined">;
      minPasswordLength: z<number, number, "defined">;
      maxJoinAttempts: z<number, number, "defined">;
      joinAttemptWindowMs: z<number, number, "defined">;
      joinLockoutMs: z<number, number, "defined">;
      ticketTtlMs: z<number, number, "defined">;
      idleTtlMs: z<number, number, "defined">;
      closeWhenOwnerLeaves: z<boolean, boolean, "defined">;
      discoverableByDefault: z<boolean, boolean, "defined">;
      allowRoomList: z<boolean, boolean, "defined">;
    }>>, Schemastery.ObjectT<NoInfer<{
      maxRooms: z<number, number, "defined">;
      maxRoomsPerDevice: z<number, number, "defined">;
      maxMembersPerRoom: z<number, number, "defined">;
      roomCodeLength: z<number, number, "defined">;
      minPasswordLength: z<number, number, "defined">;
      maxJoinAttempts: z<number, number, "defined">;
      joinAttemptWindowMs: z<number, number, "defined">;
      joinLockoutMs: z<number, number, "defined">;
      ticketTtlMs: z<number, number, "defined">;
      idleTtlMs: z<number, number, "defined">;
      closeWhenOwnerLeaves: z<boolean, boolean, "defined">;
      discoverableByDefault: z<boolean, boolean, "defined">;
      allowRoomList: z<boolean, boolean, "defined">;
    }>>, "defined">;
  }>>, "plain">;
  apply: typeof apply;
};
//#endregion
export { Config, CrossTransferConfig, DeviceInfo, RoomGateway, SessionInfo, apply, _default as default, inject, name };
//# sourceMappingURL=index.d.ts.map