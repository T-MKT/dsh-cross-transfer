import z from "@deepseek-ai/schemastery";
import { Context, Service } from "@deepseek-ai/cordis";
import { WebSocket } from "ws";
import { IncomingMessage } from "http";

//#region src/chat.d.ts
interface ChatConfig {
  maxHistoryPerRoom: number;
  maxMessageLength: number;
}
interface ChatMessage {
  messageId: string;
  roomId: string;
  senderDeviceId: string;
  senderDeviceName: string;
  senderSessionId: string;
  content: string;
  type: 'text' | 'system' | 'file' | 'code';
  metadata?: Record<string, unknown>;
  timestamp: number;
  edited?: boolean;
  replyTo?: string;
}
interface ChatRoom {
  roomId: string;
  name: string;
  createdAt: number;
  participantCount: number;
  lastMessageAt: number;
}
interface ChatEvents {
  'message': [message: ChatMessage];
  'message-edited': [message: ChatMessage];
  'message-deleted': [messageId: string, roomId: string];
  'room-created': [room: ChatRoom];
  'user-joined': [roomId: string, deviceId: string, deviceName: string];
  'user-left': [roomId: string, deviceId: string];
  'typing': [roomId: string, deviceId: string, deviceName: string, isTyping: boolean];
}
declare class ChatService extends Service {
  private config;
  private rooms;
  private userRooms;
  private emitter;
  constructor(ctx: Context);
  on<K extends keyof ChatEvents>(event: K, listener: (...args: ChatEvents[K]) => void): () => void;
  off<K extends keyof ChatEvents>(event: K, listener: (...args: ChatEvents[K]) => void): void;
  emit<K extends keyof ChatEvents>(event: K, ...args: ChatEvents[K]): void;
  once<K extends keyof ChatEvents>(event: K, listener: (...args: ChatEvents[K]) => void): () => void;
  initialize(config?: Partial<ChatConfig>): void;
  createRoom(roomId: string, name: string): ChatRoom;
  getRoom(roomId: string): ChatRoom | undefined;
  getRooms(): ChatRoom[];
  joinRoom(deviceId: string, deviceName: string, roomId?: string): boolean;
  leaveRoom(deviceId: string, deviceName: string, roomId: string): boolean;
  sendMessage(data: {
    roomId: string;
    senderDeviceId: string;
    senderDeviceName: string;
    senderSessionId: string;
    content: string;
    type?: 'text' | 'system' | 'file' | 'code';
    metadata?: Record<string, unknown>;
    replyTo?: string;
  }): ChatMessage;
  editMessage(messageId: string, roomId: string, newContent: string, deviceId: string): ChatMessage | null;
  deleteMessage(messageId: string, roomId: string, deviceId: string): boolean;
  getHistory(roomId: string, limit?: number, before?: number): ChatMessage[];
  setTyping(roomId: string, deviceId: string, deviceName: string, isTyping: boolean): void;
  getParticipants(roomId: string): string[];
  getUserRooms(deviceId: string): string[];
  private generateMessageId;
  shutdown(): void;
}
//# sourceMappingURL=chat.d.ts.map
//#endregion
//#region src/rooms.d.ts
type RoomRole = 'owner' | 'member';
/** 房号：4~12 位纯数字字符串 */
type RoomId = string;
/** 设备身份凭据（256-bit hex）。客户端自存、服务端只认它，deviceId 由它派生 */
type DeviceSecret = string;
/**
 * 房间的公开投影。不含 sessionId、不含票据、不含任何凭据。
 * ownerDeviceId 在对外投影里必须脱敏（见 maskDeviceId），因为它不是凭据但也不该被枚举。
 */
interface RoomInfo {
  roomId: RoomId;
  name: string;
  /** 脱敏房主设备 id（前 4 + '…' + 后 4）。用于 UI 判断「我是不是房主」，不是授权依据 */
  ownerDeviceId: string;
  /** 房主当前是否有活会话 */
  ownerOnline: boolean;
  createdAt: number;
  lastActivityAt: number;
  /** 成员行数，含离线但保留席位的成员 */
  memberCount: number;
  maxMembers: number;
  locked: boolean;
  discoverable: boolean;
  /**
   * 房间是否已配置 Git 仓库（契约 §3）。
   * 公开投影只暴露这个布尔值，绝不暴露 URL、分支或凭据——仓库细节只经
   * RoomRepoStatus（脱敏后）流转，避免从房间列表/详情里泄漏远端地址。
   */
  repoConfigured: boolean;
}
/** 成员视图。deviceId 同样脱敏；sessionIds 集合永不外泄，只暴露计数与在线位。 */
interface RoomMember {
  deviceId: string;
  deviceName: string;
  role: RoomRole;
  joinedAt: number;
  sessionCount: number;
  online: boolean;
}
/** 票据的服务端记录 */
interface RoomTicket {
  ticket: string;
  roomId: RoomId;
  deviceId: string;
  role: RoomRole;
  issuedAt: number;
  expiresAt: number;
}
type RoomCloseReason = 'closed-by-owner' | 'idle-timeout' | 'owner-left';
/** 只描述非惩罚性离开；被踢走 member-kicked 事件 */
type RoomLeaveReason = 'left' | 'disconnected';
interface DeviceCredential {
  deviceSecret: string;
  deviceId: string;
  deviceName: string;
  createdAt: number;
  lastSeenAt: number;
}
interface DeviceRegisterRequest {
  /** 首次登记时省略；服务端铸一个新 secret 并返回 */
  deviceSecret?: DeviceSecret;
  deviceName?: string;
}
interface DeviceRegisterResult {
  deviceId: string;
  deviceSecret: DeviceSecret;
  deviceName: string;
  /** 与 deviceId+tokenSecret 对应的连接 token，免再调一次 /token */
  token: string;
}
interface RoomConfig {
  maxRooms: number;
  maxRoomsPerDevice: number;
  maxMembersPerRoom: number;
  roomCodeLength: number;
  minPasswordLength: number;
  maxJoinAttempts: number;
  joinAttemptWindowMs: number;
  joinLockoutMs: number;
  ticketTtlMs: number;
  idleTtlMs: number;
  closeWhenOwnerLeaves: boolean;
  discoverableByDefault: boolean;
  allowRoomList: boolean;
}
interface RoomEvents {
  'room-created': [room: RoomInfo, memberSessionIds: string[]];
  'room-closed': [roomId: RoomId, reason: RoomCloseReason, memberSessionIds: string[]];
  'member-joined': [roomId: RoomId, member: RoomMember, memberSessionIds: string[]];
  'member-left': [roomId: RoomId, deviceId: string, reason: RoomLeaveReason, memberSessionIds: string[]];
  'member-kicked': [roomId: RoomId, deviceId: string, kickedByDeviceId: string, targetSessionIds: string[], memberSessionIds: string[]];
  'owner-changed': [roomId: RoomId, newOwnerDeviceId: string, memberSessionIds: string[]];
  'password-changed': [roomId: RoomId, memberSessionIds: string[]];
  'lock-changed': [roomId: RoomId, locked: boolean, memberSessionIds: string[]];
}
interface CreateRoomRequest {
  roomId?: RoomId;
  name?: string;
  password: string;
  maxMembers?: number;
  discoverable?: boolean;
  deviceId: string;
  deviceName: string;
  sessionId?: string;
  remoteAddress?: string;
}
interface JoinRoomRequest {
  roomId: RoomId;
  password: string;
  deviceId: string;
  deviceName: string;
  sessionId?: string;
  remoteAddress?: string;
}
interface RoomJoinResult {
  room: RoomInfo;
  member: RoomMember;
  ticket: RoomTicket;
}
interface RoomLeaveResult {
  roomId: RoomId;
  deviceId: string;
  /** 成员行是否被移除（显式退房 true；仅会话断开 false） */
  removed: boolean;
  /** closeWhenOwnerLeaves=true 且房主退房 */
  closed: boolean;
  newOwnerDeviceId?: string;
}
/** deviceId = sha256('xfer-device:' + secret).slice(0, 16)。secret 是 32 字节 hex。 */

/** 密码哈希参数快照，随每条哈希一起存，便于将来升级参数而不作废旧房间。 */
interface ScryptParams {
  N: number;
  r: number;
  p: number;
}
declare class RoomService extends Service {
  private config;
  private scryptParams;
  private rooms;
  private credentials;
  private tickets;
  private createReservations;
  private sessionRooms;
  private closedRooms;
  private failureWindows;
  private lockouts;
  private sweepTimer;
  private emitter;
  constructor(ctx: Context);
  on<K extends keyof RoomEvents>(event: K, listener: (...args: RoomEvents[K]) => void): () => void;
  off<K extends keyof RoomEvents>(event: K, listener: (...args: RoomEvents[K]) => void): void;
  emit<K extends keyof RoomEvents>(event: K, ...args: RoomEvents[K]): void;
  once<K extends keyof RoomEvents>(event: K, listener: (...args: RoomEvents[K]) => void): () => void;
  initialize(config?: Partial<RoomConfig>): void;
  shutdown(): void;
  /** 当前配置的浅拷贝，只读用。 */
  getConfig(): RoomConfig;
  /**
   * 登记或凭已有 secret 取回身份。
   * 未登记 + 无 secret → invalid-device（调用方应先走 /devices/register）。
   */
  registerDevice(request: DeviceRegisterRequest): DeviceRegisterResult;
  /** 解析并刷新 lastSeenAt；未登记 → invalid-device */
  authenticateDevice(deviceSecret: DeviceSecret | undefined, deviceId: string): DeviceCredential;
  /**
   * 该 deviceId 是否已被登记为凭据。凭据表以 deviceSecret 为键，这里按值扫一遍：
   * 只在 legacy token 回落这类低频路径上调用。legacy 回落必须拒掉已登记的
   * deviceId——已登记 id 是别人的身份，无凭据给它铸连接 token 就等于冒充
   * 已登记成员/房主（deviceId 本身在系统内不是秘密，可经设备列表或广播枚举到）。
   */
  hasDeviceId(deviceId: string): boolean;
  private normalizeDeviceName;
  private evictCredentials;
  createRoom(request: CreateRoomRequest): Promise<RoomJoinResult>;
  joinRoom(request: JoinRoomRequest): Promise<RoomJoinResult>;
  /** 设备级显式退房：移除成员行与该设备全部会话（含同设备其它标签页） */
  leaveRoom(roomId: RoomId, deviceId: string): Promise<RoomLeaveResult>;
  /** 关房（仅房主） */
  closeRoom(roomId: RoomId, actorDeviceId: string): Promise<void>;
  /**
   * 踢人（仅房主；不能踢自己）。移除成员行 + 摘掉其全部会话 + 清 sessionRooms + 吊票据。
   * 三者缺一：行还在就会被快速通道无密码放回，会话还挂就会被 isSessionMember 放行。
   */
  kickMember(roomId: RoomId, actorDeviceId: string, targetDeviceId: string): Promise<void>;
  changePassword(roomId: RoomId, actorDeviceId: string, password: string): Promise<void>;
  setLocked(roomId: RoomId, actorDeviceId: string, locked: boolean): Promise<void>;
  /** 可发现房间的公开投影。关闭房间列表时一律为空（fail-closed）。 */
  listRooms(): RoomInfo[];
  getRoomInfo(roomId: RoomId, actorDeviceId: string): RoomInfo;
  /**
   * 成员列表。只有该房成员能读；deviceId 一律脱敏（契约 §1.1：成员视图不分视角）。
   * 真实 id 只经 user-joined / member-kicked 等推送语义流转，不从列表反查——
   * 否则房主视角就成了把真 id 集中放在一个可读响应里的泄漏点。
   */
  getMembers(roomId: RoomId, actorDeviceId: string): RoomMember[];
  /**
   * 标记房间是否已配置 Git 仓库（契约 §3）。
   *
   * 由 RoomWorkspaceService 在房主配置/清除仓库后调用。这里只翻一个布尔位：
   * 不更新 lastActivityAt（它不是成员活动，不该让房间免于空闲回收），
   * 也不发房间事件——状态广播归 RoomWorkspaceService 的 'status-changed'，
   * 两处各发一次会让客户端刷新两遍。
   */
  setRepoConfigured(roomId: RoomId, value: boolean): void;
  /** 含建房占位（见并发与原子性约定） */
  hasRoom(roomId: RoomId): boolean;
  /** 含建房占位（每间在途建房只算一次，见 occupiedRoomCount） */
  getRoomCount(): number;
  roomCountForDevice(deviceId: string): number;
  authenticate(ticket: string, roomId: RoomId): RoomTicket;
  /** 解析 Authorization: Bearer <ticket 或 deviceSecret>。两者都不认时 → invalid-ticket。 */
  authenticateBearer(authorization: string | undefined, roomId?: RoomId): {
    ticket?: RoomTicket;
    credential?: DeviceCredential;
  };
  isMember(roomId: RoomId, deviceId: string): boolean;
  isOwner(roomId: RoomId, deviceId: string): boolean;
  isSessionMember(roomId: RoomId, deviceId: string, sessionId: string): boolean;
  getMemberSessionIds(roomId: RoomId): string[];
  touch(roomId: RoomId): void;
  /**
   * 会话断开：摘掉会话，保留席位（online=false）。返回受影响的房间。
   * 不吊销票据：契约 §1.10 的吊销清单只有显式退房/被踢/关房/改密/回收，断线不在其中；
   * 票据按 (roomId, deviceId) 记账不分 会话，这里若顺手吊销，同设备仍在线会话的
   * 房间凭据会被一次标签页关闭连带作废（test/rooms-limits.test.ts 多会话票据用例）。
   */
  dropSession(sessionId: string, deviceId: string): RoomId[];
  /** 一次主动清扫：过期票据 / 墓碑 / 占位 / 凭据 + 空闲回收。测试可手动调。 */
  sweep(now?: number): void;
  /** 仅供测试提速：调低 scrypt 成本。生产路径不碰它。 */
  setScryptParams(params: Partial<ScryptParams>): void;
  private assertRoomId;
  private assertCustomRoomId;
  private assertPassword;
  private normalizeMaxMembers;
  private normalizeRoomName;
  private pickRandomRoomId;
  private hashPassword;
  private verifyPassword;
  private issueTicket;
  private revokeTickets;
  private revokeTicketsFor;
  private ticketsForDevice;
  private attachSession;
  /** 摘掉某设备的全部会话（含 sessionRooms 索引），但保留成员行。 */
  private detachDeviceSessions;
  private refreshCounts;
  private memberSessionIds;
  private transferOwnership;
  private closeRoomInternal;
  private ownedRoomCount;
  /**
   * 全局房间占用数 = 已建成的房间 + 在途占位。占位 record 会同时写进 rooms
   * （passwordHash=null）与 createReservations 两张表，直接把两个 size 相加会把
   * 同一间在途建房算两次，并发建房在还有一半名额时就会被误拒
   * （test/rooms-limits.test.ts「并发建房在还有名额时不得被误拒」）。
   */
  private occupiedRoomCount;
  private pruneReservations;
  private pruneClosedRooms;
  private visibleRooms;
  private requireVisibleRoom;
  private projectRoom;
  private projectMember;
  private assertNotLocked;
  private recordFailure;
  /**
   * 清失败计数与锁定。'all' 用于「刚验证过密码/刚建成房间」的场景，设备键与
   * 共享 ip 键一起清（test/rooms.test.ts「成功进房也会清掉该 IP 的失败计数」）；
   * 'device-only' 用于成员快速通道——它没验证任何凭据之外的东西，共享的
   * ip:<roomId>:<addr> 桶属于同 IP 的所有设备，不能被一次免密回房清掉。
   */
  private clearFailures;
  private rateLimitKeys;
  private runMaintenance;
  private reapIdleRooms;
}
//#endregion
//#region src/git-sync.d.ts
interface RepoConfig {
  repoId: string;
  name: string;
  localPath: string;
  remoteUrl: string;
  branch: string;
  auth?: {
    type: 'token' | 'ssh';
    token?: string;
    username?: string;
    sshKeyPath?: string;
    passphrase?: string;
  };
  autoSync?: boolean;
  syncInterval?: number;
}
interface SyncOptions {
  operation: 'fetch' | 'pull' | 'push' | 'status';
  remote?: string;
  branch?: string;
  force?: boolean;
}
interface SyncResult {
  success: boolean;
  operation: string;
  repoId: string;
  output?: string;
  error?: string;
  conflicts?: string[];
  filesChanged?: number;
  commitsAhead?: number;
  commitsBehind?: number;
}
/**
 * 房间工作区仓库的初始化入参（契约 §4.1）。
 *
 * auth 复用 RepoConfig['auth'] 而不是从 room-workspace.ts 引 RoomRepoAuthInput：
 * 那会形成 rooms → room-workspace → git-sync → room-workspace 的循环依赖。
 * 形状上两者本来就一致（token + 可选 username），复用即可。
 */
interface EnsureRepoInput {
  repoId: string;
  name: string;
  localPath: string;
  remoteUrl: string;
  branch: string;
  auth?: RepoConfig['auth'];
}
/**
 * 一次「提交 + 按需推送」的结果（契约 §4.1）。
 *
 * ok 表示「提交成功且（未要求 push 或 push 成功）」。任何失败都不抛，
 * 只把截断后的原因放进 error，让调用方能原样显示给用户。
 */
interface CommitPushResult {
  ok: boolean;
  /** 本次实际 stage 的文件数（add + remove）；无变化时为 0 */
  committed: number;
  commitOid?: string;
  pushed: boolean;
  error?: string;
}
interface GitSyncEvents {
  'sync-started': [repoId: string, operation: string];
  'sync-progress': [repoId: string, progress: {
    phase: string;
    loaded: number;
    total: number;
  }];
  'sync-complete': [result: SyncResult];
  'sync-failed': [repoId: string, error: Error, operation: string];
  'conflict-detected': [repoId: string, conflicts: string[]];
  'repo-registered': [config: RepoConfig];
  'repo-unregistered': [repoId: string];
  'auto-sync-triggered': [repoId: string];
}
declare class GitSyncService extends Service {
  private repos;
  private syncIntervals;
  private fsPromises;
  private emitter;
  constructor(ctx: Context);
  on<K extends keyof GitSyncEvents>(event: K, listener: (...args: GitSyncEvents[K]) => void): () => void;
  off<K extends keyof GitSyncEvents>(event: K, listener: (...args: GitSyncEvents[K]) => void): void;
  emit<K extends keyof GitSyncEvents>(event: K, ...args: GitSyncEvents[K]): void;
  once<K extends keyof GitSyncEvents>(event: K, listener: (...args: GitSyncEvents[K]) => void): () => void;
  initialize(): void;
  registerRepo(config: Omit<RepoConfig, 'repoId'> & {
    repoId?: string;
  }): Promise<RepoConfig>;
  unregisterRepo(repoId: string): Promise<boolean>;
  getRepos(): RepoConfig[];
  getRepo(repoId: string): RepoConfig | undefined;
  /**
   * 把宿主工作区目录登记成房间仓库（契约 §4.1 / §4.2 规则 3）。
   *
   * 与 registerRepo 的区别（都是刻意的）：
   * - 目录必须已存在且是目录，**不 mkdir**——成员绑定的是自己机器上已有的
   *   工作区，替他造目录既越权又可能造到错误位置。
   * - 绝不写 credential.helper。旧 configureAuth 会把明文 token 写进
   *   .git/config，任何能读工作区的人都能拿到；新路径只让 auth 走回调。
   */
  ensureRepo(input: EnsureRepoInput): Promise<RepoConfig>;
  /**
   * 暂存工作区全部改动（新增/修改/删除）→ 有变化才提交 → 按需推送（契约 §4.1）。
   *
   * 全程不抛：repo 缺失、提交失败、push 失败、超时都变成返回值里的 error。
   * 也不发 sync-started/sync-complete/sync-failed——那些事件属于手动 syncRepo
   * 的既有契约，这里的调用方是回合结束钩子，高频且无需逐次进度播报。
   */
  commitAndPush(repoId: string, options: {
    message: string;
    authorName: string;
    authorEmail: string;
    push: boolean;
    timeoutMs?: number;
  }): Promise<CommitPushResult>;
  /**
   * 当前分支与最近提交（契约 §4.1，给状态展示用）。
   *
   * 分支尚未产生任何提交时 resolveRef 会失败；那就只回分支名。
   * repo 不存在或 HEAD 不可解都吞掉返回 {}——这是只读投影，不该因展示失败报错。
   */
  getHead(repoId: string): Promise<{
    branch?: string;
    commitOid?: string;
  }>;
  /**
   * 本地是否已经有 `repo.branch` 这个分支。
   *
   * 工作区刚 init、还没有任何提交时不存在分支，此时 push 只会得到一个
   * NotFoundError——那不是「远端不可达」，而是「没什么可推」，报成失败会误导。
   * 提交数为 0 但仍要 push（补推上次失败的分支）时会先用它挡一下。
   */
  private hasLocalBranch;
  syncRepo(repoId: string, options: SyncOptions): Promise<SyncResult>;
  private fetch;
  private pull;
  private push;
  private status;
  /** Count commits reachable from `from` but not from `stop`, first-parent walk. */
  private countCommits;
  private configureAuth;
  private getAuthCallback;
  /** The node HTTP client `fetch`/`pull`/`push` require; absent = those calls reject. */
  private getHttpClient;
  private startAutoSync;
  private stopAutoSync;
  private generateRepoId;
  shutdown(): void;
}
//# sourceMappingURL=git-sync.d.ts.map
//#endregion
//#region src/room-workspace.d.ts
interface RoomRepoAuthInput {
  /** 仅支持 token 形式（HTTPS Basic）。 */
  type: 'token';
  token: string;
  /** 默认 'oauth2'（GitHub）或 'git'。 */
  username?: string;
}
interface RoomRepoConfigInput {
  /** 必须是 http:// 或 https://；允许内嵌 userinfo，会被抽取成 auth 并从存储值里剥离。 */
  remoteUrl: string;
  /** 默认 'main'。 */
  branch?: string;
  auth?: RoomRepoAuthInput;
  /** 默认 true。 */
  autoCommit?: boolean;
  /** 默认 true。 */
  autoPush?: boolean;
  commitAuthorName?: string;
  commitAuthorEmail?: string;
}
/** 对外投影：绝不包含 token、绝不包含未剥离 userinfo 的 URL。 */
interface RoomRepoStatus {
  roomId: string;
  configured: boolean;
  /** 已剥离 userinfo；未配置时省略。 */
  remoteUrl?: string;
  branch?: string;
  authConfigured: boolean;
  autoCommit: boolean;
  autoPush: boolean;
  updatedAt?: number;
  /** 脱敏。 */
  updatedByDeviceId?: string;
  bindings: WorkspaceBindingStatus[];
}
interface WorkspaceBindingStatus {
  /** 脱敏 deviceId。 */
  deviceId: string;
  deviceName: string;
  bound: boolean;
  /** 只对绑定者本人与房主返回真实路径；其他成员看到 undefined。 */
  workspacePath?: string;
  repoReady?: boolean;
  lastSync?: SyncSummary;
}
interface SyncSummary {
  at: number;
  ok: boolean;
  trigger: 'auto' | 'manual';
  /** 本次提交的文件数（含删除）。 */
  committed: number;
  commitOid?: string;
  pushed: boolean;
  error?: string;
}
interface RoomGitConfig {
  enabled: boolean;
  /** 自动同步的合并窗口（毫秒），默认 1500。 */
  debounceMs: number;
  /** 单次 push 超时，默认 60000。 */
  pushTimeoutMs: number;
  /** 每个房间最多保留的绑定数，默认 16。 */
  maxBindingsPerRoom: number;
  /** 候选目录上限，默认 50。 */
  maxCandidates: number;
}
/** roomGit 默认值（契约 §4.2 与 §4.6 的 schemastery 默认值必须一致）。 */

/** 本服务的事件表（自建 typed emitter，不覆盖 Service/Context 的 on/emit，§4.2）。 */
interface RoomWorkspaceEvents {
  'status-changed': [roomId: string, status: RoomRepoStatus];
  'sync-finished': [roomId: string, deviceId: string, summary: SyncSummary];
}
declare class RoomWorkspaceService extends Service {
  private readonly rooms;
  private readonly gitSync;
  private config;
  private states;
  private emitter;
  constructor(ctx: Context, rooms: RoomService, gitSync: GitSyncService);
  on<K extends keyof RoomWorkspaceEvents>(event: K, listener: (...args: RoomWorkspaceEvents[K]) => void): () => void;
  off<K extends keyof RoomWorkspaceEvents>(event: K, listener: (...args: RoomWorkspaceEvents[K]) => void): void;
  emit<K extends keyof RoomWorkspaceEvents>(event: K, ...args: RoomWorkspaceEvents[K]): void;
  once<K extends keyof RoomWorkspaceEvents>(event: K, listener: (...args: RoomWorkspaceEvents[K]) => void): () => void;
  initialize(config?: Partial<RoomGitConfig>): void;
  /**
   * 纯校验（契约 §4.2 规则 2）：不联网、不落盘，建房前先挡一次，
   * 免得建出一个「仓库配错了」的半成品房间。
   *
   * enabled=false 也在这里挡：否则带 repo 的建房会「先把房间建出来、再因 configureRepo
   * 回 forbidden」，留下一个配不上仓库的房间。开关判定同样是纯内存的，符合「纯校验」。
   */
  validateRepoConfig(input: RoomRepoConfigInput): void;
  configureRepo(roomId: string, actorDeviceId: string, input: RoomRepoConfigInput): Promise<RoomRepoStatus>;
  clearRepo(roomId: string, actorDeviceId: string): Promise<RoomRepoStatus>;
  bindWorkspace(roomId: string, deviceId: string, workspacePath: string): Promise<RoomRepoStatus>;
  unbindWorkspace(roomId: string, deviceId: string): Promise<RoomRepoStatus>;
  /**
   * 手动/自动同步。手动（默认）永远提交；自动触发在 autoCommit=false 时直接跳过（规则 4）。
   *
   * 失败不抛（结果里带 ok=false，规则 4）；只有「绑定已不存在」这类调用方错误才抛
   * sync-failed —— 契约 §4.3 把这个码留给这一层。
   */
  sync(roomId: string, deviceId: string, trigger?: 'auto' | 'manual'): Promise<SyncSummary>;
  status(roomId: string, viewerDeviceId: string): RoomRepoStatus;
  /**
   * 候选工作区目录（契约 §4.2 规则 7）。
   *
   * 只是「省一次手输」的便利功能：宿主服务形状不确定（workspaceRegistry 尤其），
   * 任何依赖缺失或形状不符都静默跳过，绝不抛。
   */
  candidates(): Promise<string[]>;
  /**
   * cwd 命中绑定 → 去抖后提交+推送（契约 §4.2 规则 5）。
   *
   * 返回本次触发的同步结果：被去抖合并进同一窗口的触发拿到的是同一个 promise，
   * 因此可能返回重复的 SyncSummary；没有任何绑定命中时返回 []。
   */
  handleWorkspaceChanges(cwd: string, summary: {
    files: {
      path: string;
    }[];
    total: number;
  }): Promise<SyncSummary[]>;
  /**
   * 订阅 dsh 的 'session/event'，读 workspaceChanges.summary（契约 §4.2 attachHost）。
   *
   * 依赖缺失时只记一条 info 并退化成空函数：插件其余功能必须照常可用，
   * 绝不能因为宿主没有这个服务就抛。返回退订函数。
   */
  attachHost(): () => void;
  /**
   * 房间关闭：清掉该房配置与绑定并清定时器（契约 §4.2 规则 6）。
   *
   * 由 RoomGateway 在 'room-closed' 事件里调用（含房主关房、房主离开、空闲回收）。
   * 不清的话内存里的明文 token 会一直留到进程退出。被踢/退房走的是 unbindWorkspace，
   * 那条路径对「已不在房间、但还留着本房绑定」的设备是放行的。
   */
  onRoomClosed(roomId: string): void;
  shutdown(): void;
  /**
   * 串行与合并（契约 §4.2 规则 4）：
   * - 同一绑定任何时刻只跑一次 git 操作；
   * - 运行期间来的触发只置脏，结束后补跑一次，且所有被合并的触发复用同一个 promise。
   */
  private enqueueSync;
  private startRun;
  private performSync;
  private finishSync;
  private scheduleAutoSync;
  private flushAutoSync;
  /**
   * 清掉去抖定时器并兑现等待者。
   *
   * 必须兑现：handleWorkspaceChanges 的 Promise.all 会一直挂着，否则关房/解绑就成了
   * 「调用方永远等不到结果」。
   */
  private cancelPending;
  /**
   * 归一化 + 校验（契约 §4.2 规则 2）。纯内存：不联网、不碰磁盘。
   */
  private normalizeRepoConfig;
  private normalizeAuth;
  /**
   * 按视角投影（§3）：token 永不出现；remoteUrl 已剥离 userinfo；工作区路径只对
   * 绑定者本人与房主可见。
   *
   * 成员行来自房间成员表而不是绑定表：WorkspaceBindingStatus.bound 与 §5.2 的
   * 「每个成员一行（已绑定/未绑定）」都要求未绑定的成员也出现。已不在房间的残留绑定
   * 追加在末尾，否则它既看不见又清不掉。
   */
  private project;
  /** 双保险：存储值本来就已剥离，这里再剥一次，任何路径都别想把凭据送出去（§3）。 */
  private sanitizeRemoteUrl;
  private assertMember;
  private assertOwner;
  /** roomGit.enabled === false 时所有写操作一律 forbidden（规则 2 最后一条）。 */
  private assertEnabled;
  private ensureState;
  private roomLabel;
  /**
   * 提交信息（契约 §4.2 规则 4）：`chore(cross-transfer): <房间名或 roomId> 自动同步 <N> 个文件`。
   *
   * N 超过 20 时只展示 20 并在末尾附 `…(+K)`（K = N - 20）：契约里 20 这个阈值的作用就是
   * 截断，`…(+K)` 是「还有 K 个未列出」的惯用写法；基础模板本身保持逐字不变，多出来的
   * 标记是「附」在整条信息末尾的。
   */
  private buildCommitMessage;
  /**
   * 数一遍「本次会被提交的文件数」，只为了把 N 写进提交信息（规则 4）。
   *
   * 为什么在这里数：§4.1 的 commitAndPush 只在提交之后才返回计数，签名已冻结，
   * 提交前拿不到那个数字。判定规则与 §4.1 完全一致（workdir===2 新增/修改，
   * head===1 且 workdir===0 删除），所以正常情况下两个数字相等。
   */
  private countChanges;
  /** 事件派发是同步的：这里绝不能 await，否则会拖住整条事件链。 */
  private onSessionEvent;
  /**
   * 路径规范化（规则 3）：realpathSync.native 会解掉符号链接、统一盘符大小写与 8.3 短名，
   * 两次绑定同一个目录、以及回合结束时的 cwd 才能对得上。
   */
  private normalizePath;
  /** Windows 文件系统大小写不敏感（规则 3）：比较键统一小写才不会漏匹配。 */
  private pathKey;
  private nonNegative;
  private nonEmpty;
  private skippedSummary;
}
//# sourceMappingURL=room-workspace.d.ts.map
//#endregion
//#region src/ws-server.d.ts
interface WSServerConfig {
  path: string;
  tokenSecret: string;
  maxFileSize: number;
  chunkSize: number;
}
interface WSSession {
  sessionId: string;
  deviceId: string;
  deviceName: string;
  connectedAt: number;
  lastActiveAt: number;
  socket: WebSocket;
  capabilities: Set<string>;
  authenticated: boolean;
  /** 远端地址；用于按 IP 限流。必须由 handleConnection 赋值 */
  remoteAddress?: string;
}
/**
 * The public shape of a session: everything above except the socket, which is
 * never handed out (the server service owns it, not a caller), and except the
 * remote address, which is peer topology rather than session state.
 */
type WSSessionSummary = Omit<WSSession, 'socket' | 'capabilities' | 'remoteAddress'> & {
  /** Capabilities as a JSON-safe array; the live session holds a Set. */
  capabilities: string[];
};
interface WSMessage {
  type: string;
  sessionId?: string;
  deviceId?: string;
  targetDeviceId?: string;
  payload: unknown;
  messageId?: string;
}
/**
 * The room gate owns every message that carries room semantics: room lifecycle,
 * room-scoped chat, and any custom type whose payload names a room. It is a port
 * so src/ws-server.ts never depends on the room implementation.
 */
interface RoomGate {
  /** Non-null reply means "answer the requesting session"; null means the gate already broadcast. */
  handle(session: WSSession, message: WSMessage, server: WSServer): Promise<RoomGateReply | null>;
  onSessionClosed(session: WSSession): void;
}
interface RoomGateReply {
  type: string;
  payload: unknown;
}
interface WSServerEvents {
  connection: [session: WSSession];
  disconnection: [sessionId: string, reason: string];
  message: [session: WSSession, message: WSMessage];
  deviceConnected: [device: DeviceInfo$1];
  deviceDisconnected: [deviceId: string];
  error: [error: Error, session?: WSSession];
}
interface DeviceInfo$1 {
  deviceId: string;
  deviceName: string;
  connectedAt: number;
  lastActiveAt: number;
  sessionCount: number;
  capabilities: string[];
}
declare class WSServer extends Service {
  private wss;
  private config;
  private sessions;
  private deviceRegistry;
  private messageHandlers;
  private pendingRequests;
  private roomGate;
  private emitter;
  constructor(ctx: Context);
  on<K extends keyof WSServerEvents>(event: K, listener: (...args: WSServerEvents[K]) => void): () => void;
  off<K extends keyof WSServerEvents>(event: K, listener: (...args: WSServerEvents[K]) => void): void;
  emit<K extends keyof WSServerEvents>(event: K, ...args: WSServerEvents[K]): void;
  once<K extends keyof WSServerEvents>(event: K, listener: (...args: WSServerEvents[K]) => void): () => void;
  initialize(config: WSServerConfig): void;
  handleUpgrade(req: IncomingMessage, socket: any, head: Buffer): void;
  private handleConnection;
  private handleMessage;
  /**
   * A message carries room semantics when its type is room-scoped by name, or
   * when its payload names a room. The payload arm exists because a client
   * cannot be trusted to stay inside the documented type list: any custom type
   * that mentions a roomId would otherwise fall through to broadcastToAll.
   */
  isRoomScoped(message: WSMessage): boolean;
  private handleRoomScoped;
  /** 唯一的错误帧来源，保证 messageId 回显规则只有一处实现。 */
  private sendRoomError;
  private handleDisconnection;
  private registerDefaultHandlers;
  onMessage(type: string, handler: (session: WSSession, message: WSMessage) => Promise<void>): void;
  /** 只在 src/index.ts 调用：唯一的门禁安装点。 */
  setRoomGate(gate: RoomGate | null): void;
  getRoomGate(): RoomGate | null;
  sendToSession(sessionId: string, message: WSMessage): boolean;
  broadcastToDevice(deviceId: string, message: WSMessage, excludeSessionId?: string): number;
  broadcastToAll(message: WSMessage, excludeSessionId?: string): number;
  /**
   * Deliver to an explicit recipient set. Room delivery goes through here
   * because only the room gate knows who is currently in the room.
   * @returns how many sessions the frame actually reached.
   */
  broadcastToSessions(sessionIds: Iterable<string>, message: WSMessage, excludeSessionId?: string): number;
  request(sessionId: string, message: WSMessage, timeoutMs?: number): Promise<unknown>;
  getDevices(): DeviceInfo$1[];
  /** Session summaries: the socket itself never leaves this service. */
  getSessions(): WSSessionSummary[];
  getSession(sessionId: string): WSSession | undefined;
  getDeviceSessions(deviceId: string): WSSession[];
  private generateSessionId;
  private generateDeviceId;
  private validateToken;
  shutdown(): void;
}
//# sourceMappingURL=ws-server.d.ts.map
//#endregion
//#region src/index.d.ts
/** Cordis plugin name. */
declare const name = "cross-transfer";
/** The route carrier this plugin mounts onto. */
declare const inject: string[];
interface CrossTransferConfig {
  /** Absolute route prefix, no trailing slash. */
  path: string;
  /** Shared secret for device tokens; generated per boot when omitted. */
  tokenSecret?: string;
  maxFileSize: number;
  chunkSize: number;
  /** 房间能力配置；schema 给每一项都配了默认值，旧配置不带 rooms 也能启动。 */
  rooms: RoomConfig;
  /**
   * 房间 Git 工作区同步配置（契约 §4.6）；整块可选，旧配置不带 roomGit 也能启动。
   * 形状必须是 RoomGitConfig 而不是 Partial：schema 已经把每一项都补成默认值了，
   * 缺省值的唯一来源是 Config 的 z.object，避免两处默认值漂移。
   */
  roomGit?: RoomGitConfig;
}
interface DeviceInfo {
  deviceId: string;
  deviceName: string;
  connectedAt: number;
  lastActiveAt: number;
  sessionCount: number;
  capabilities: string[];
}
interface SessionInfo {
  sessionId: string;
  deviceId: string;
  deviceName: string;
  connectedAt: number;
  lastActiveAt: number;
}
/** Validated plugin configuration. */
declare const Config: z<Schemastery.ObjectS<NoInfer<{
  path: z<string, string, "defined">;
  tokenSecret: z<string, string, "plain">;
  maxFileSize: z<number, number, "defined">;
  chunkSize: z<number, number, "defined">;
  rooms: z<Schemastery.ObjectS<NoInfer<{
    maxRooms: z<number, number, "defined">;
    maxRoomsPerDevice: z<number, number, "defined">;
    maxMembersPerRoom: z<number, number, "defined">;
    roomCodeLength: z<number, number, "defined">;
    minPasswordLength: z<number, number, "defined">;
    maxJoinAttempts: z<number, number, "defined">;
    joinAttemptWindowMs: z<number, number, "defined">;
    joinLockoutMs: z<number, number, "defined">;
    ticketTtlMs: z<number, number, "defined">;
    idleTtlMs: z<number, number, "defined">;
    closeWhenOwnerLeaves: z<boolean, boolean, "defined">;
    discoverableByDefault: z<boolean, boolean, "defined">;
    allowRoomList: z<boolean, boolean, "defined">;
  }>>, Schemastery.ObjectT<NoInfer<{
    maxRooms: z<number, number, "defined">;
    maxRoomsPerDevice: z<number, number, "defined">;
    maxMembersPerRoom: z<number, number, "defined">;
    roomCodeLength: z<number, number, "defined">;
    minPasswordLength: z<number, number, "defined">;
    maxJoinAttempts: z<number, number, "defined">;
    joinAttemptWindowMs: z<number, number, "defined">;
    joinLockoutMs: z<number, number, "defined">;
    ticketTtlMs: z<number, number, "defined">;
    idleTtlMs: z<number, number, "defined">;
    closeWhenOwnerLeaves: z<boolean, boolean, "defined">;
    discoverableByDefault: z<boolean, boolean, "defined">;
    allowRoomList: z<boolean, boolean, "defined">;
  }>>, "defined">;
  roomGit: z<Schemastery.ObjectS<NoInfer<{
    enabled: z<boolean, boolean, "defined">;
    debounceMs: z<number, number, "defined">;
    pushTimeoutMs: z<number, number, "defined">;
    maxBindingsPerRoom: z<number, number, "defined">;
    maxCandidates: z<number, number, "defined">;
  }>>, Schemastery.ObjectT<NoInfer<{
    enabled: z<boolean, boolean, "defined">;
    debounceMs: z<number, number, "defined">;
    pushTimeoutMs: z<number, number, "defined">;
    maxBindingsPerRoom: z<number, number, "defined">;
    maxCandidates: z<number, number, "defined">;
  }>>, "defined">;
}>>, Schemastery.ObjectT<NoInfer<{
  path: z<string, string, "defined">;
  tokenSecret: z<string, string, "plain">;
  maxFileSize: z<number, number, "defined">;
  chunkSize: z<number, number, "defined">;
  rooms: z<Schemastery.ObjectS<NoInfer<{
    maxRooms: z<number, number, "defined">;
    maxRoomsPerDevice: z<number, number, "defined">;
    maxMembersPerRoom: z<number, number, "defined">;
    roomCodeLength: z<number, number, "defined">;
    minPasswordLength: z<number, number, "defined">;
    maxJoinAttempts: z<number, number, "defined">;
    joinAttemptWindowMs: z<number, number, "defined">;
    joinLockoutMs: z<number, number, "defined">;
    ticketTtlMs: z<number, number, "defined">;
    idleTtlMs: z<number, number, "defined">;
    closeWhenOwnerLeaves: z<boolean, boolean, "defined">;
    discoverableByDefault: z<boolean, boolean, "defined">;
    allowRoomList: z<boolean, boolean, "defined">;
  }>>, Schemastery.ObjectT<NoInfer<{
    maxRooms: z<number, number, "defined">;
    maxRoomsPerDevice: z<number, number, "defined">;
    maxMembersPerRoom: z<number, number, "defined">;
    roomCodeLength: z<number, number, "defined">;
    minPasswordLength: z<number, number, "defined">;
    maxJoinAttempts: z<number, number, "defined">;
    joinAttemptWindowMs: z<number, number, "defined">;
    joinLockoutMs: z<number, number, "defined">;
    ticketTtlMs: z<number, number, "defined">;
    idleTtlMs: z<number, number, "defined">;
    closeWhenOwnerLeaves: z<boolean, boolean, "defined">;
    discoverableByDefault: z<boolean, boolean, "defined">;
    allowRoomList: z<boolean, boolean, "defined">;
  }>>, "defined">;
  roomGit: z<Schemastery.ObjectS<NoInfer<{
    enabled: z<boolean, boolean, "defined">;
    debounceMs: z<number, number, "defined">;
    pushTimeoutMs: z<number, number, "defined">;
    maxBindingsPerRoom: z<number, number, "defined">;
    maxCandidates: z<number, number, "defined">;
  }>>, Schemastery.ObjectT<NoInfer<{
    enabled: z<boolean, boolean, "defined">;
    debounceMs: z<number, number, "defined">;
    pushTimeoutMs: z<number, number, "defined">;
    maxBindingsPerRoom: z<number, number, "defined">;
    maxCandidates: z<number, number, "defined">;
  }>>, "defined">;
}>>, "plain">;
/**
 * 房间 WS 面的门禁：所有 room-* 与房间语义消息（chat-message / typing 等）都由它裁决。
 *
 * 它按契约本该落在独立的 src/room-gateway.ts；本单元只允许改三个文件，
 * 所以随宿主接线一起放在这里。构造只订阅事件（广播 + chat 桥接），
 * 不调用 server.setRoomGate —— 安装点在 apply() 里，测试里也各自显式安装。
 */
declare class RoomGateway implements RoomGate {
  private readonly ctx;
  private readonly rooms;
  private readonly chat;
  private readonly server;
  /**
   * 房间 Git 工作区服务（契约 §4.6）。可选：旧调用方（test/ws-server.test.ts 的
   * createRoomHarness）只传 4 个参数，此时所有 Git 相关桥接与 handler 一律退化，
   * 插件其余功能必须照常可用。
   */
  private readonly roomWorkspace?;
  private readonly offEvents;
  /** 已证明持有 deviceSecret 的设备（真 id）。建房/进房快速通道的前置条件。 */
  private readonly provenDevices;
  /** 脱敏 id → 真 id。member-joined 事件只带脱敏 id，user-joined 推送需要真 id。 */
  private readonly maskedIndex;
  constructor(ctx: Context, rooms: RoomService, chat: ChatService, server: WSServer, roomWorkspace?: RoomWorkspaceService);
  /** REST 面验证过 deviceSecret 之后登记：这个真 deviceId 由此获得进房资格。 */
  proveDevice(deviceId: string): void;
  handle(session: WSSession, message: WSMessage): Promise<RoomGateReply | null>;
  onSessionClosed(session: WSSession): void;
  /** 幂等：执行全部退订函数并清空数组。 */
  dispose(): void;
  private subscribe;
  private ensureChatRoom;
  private assertObject;
  private assertRoomId;
  /**
   * 快速通道的前置条件：这个 deviceId 必须由已登记的 deviceSecret 派生。
   * WS 连接的 token 只证明「会算 sha256」，legacy /token 回落能让自报 deviceId
   * 拿到 token，所以建房/进房必须再看一眼 REST 面登记过的凭据。
   */
  private requireProvenDevice;
  private requireSessionMember;
  /**
   * 取房间 Git 工作区服务（契约 §4.6）。
   *
   * 未接线时（旧调用方只传 4 个构造参数）明确回 room-gate-unavailable，而不是让
   * undefined 上调方法抛 TypeError —— 那会变成 internal-error，掩盖真正的原因。
   */
  private requireRoomWorkspace;
  private handleRoomCreate;
  private handleRoomJoin;
  private handleRoomLeave;
  private handleRoomClose;
  private handleRoomKick;
  private handleRoomPassword;
  private handleRoomLock;
  private handleRoomList;
  private handleRoomMembers;
  /**
   * 七个 Git/工作区 handler 的统一形状（契约 §4.5）：
   * assertRoomId → requireSessionMember（门禁只判「这个会话是不是本房成员」）→ 透传给
   * 服务层做权限判定（房主操作由服务层的 isOwner 决定 forbidden）。
   * 参数形状与取值一律交给服务层校验，门禁不重复实现第二套规则。
   */
  private handleRoomGitConfig;
  private handleRoomGitClear;
  private handleRoomGitStatus;
  private handleWorkspaceBind;
  private handleWorkspaceUnbind;
  private handleWorkspaceCandidates;
  private handleRoomGitSync;
  private handleChatMessage;
  private handleChatHistory;
  private handleTyping;
}
/**
 * Mount the WebSocket carrier and the REST surface.
 * @param ctx - plugin context carrying the `webServer` service.
 * @param config - validated plugin configuration.
 */
declare function apply(ctx: Context, config: CrossTransferConfig): void;
declare const _default: {
  name: string;
  inject: string[];
  Config: z<Schemastery.ObjectS<NoInfer<{
    path: z<string, string, "defined">;
    tokenSecret: z<string, string, "plain">;
    maxFileSize: z<number, number, "defined">;
    chunkSize: z<number, number, "defined">;
    rooms: z<Schemastery.ObjectS<NoInfer<{
      maxRooms: z<number, number, "defined">;
      maxRoomsPerDevice: z<number, number, "defined">;
      maxMembersPerRoom: z<number, number, "defined">;
      roomCodeLength: z<number, number, "defined">;
      minPasswordLength: z<number, number, "defined">;
      maxJoinAttempts: z<number, number, "defined">;
      joinAttemptWindowMs: z<number, number, "defined">;
      joinLockoutMs: z<number, number, "defined">;
      ticketTtlMs: z<number, number, "defined">;
      idleTtlMs: z<number, number, "defined">;
      closeWhenOwnerLeaves: z<boolean, boolean, "defined">;
      discoverableByDefault: z<boolean, boolean, "defined">;
      allowRoomList: z<boolean, boolean, "defined">;
    }>>, Schemastery.ObjectT<NoInfer<{
      maxRooms: z<number, number, "defined">;
      maxRoomsPerDevice: z<number, number, "defined">;
      maxMembersPerRoom: z<number, number, "defined">;
      roomCodeLength: z<number, number, "defined">;
      minPasswordLength: z<number, number, "defined">;
      maxJoinAttempts: z<number, number, "defined">;
      joinAttemptWindowMs: z<number, number, "defined">;
      joinLockoutMs: z<number, number, "defined">;
      ticketTtlMs: z<number, number, "defined">;
      idleTtlMs: z<number, number, "defined">;
      closeWhenOwnerLeaves: z<boolean, boolean, "defined">;
      discoverableByDefault: z<boolean, boolean, "defined">;
      allowRoomList: z<boolean, boolean, "defined">;
    }>>, "defined">;
    roomGit: z<Schemastery.ObjectS<NoInfer<{
      enabled: z<boolean, boolean, "defined">;
      debounceMs: z<number, number, "defined">;
      pushTimeoutMs: z<number, number, "defined">;
      maxBindingsPerRoom: z<number, number, "defined">;
      maxCandidates: z<number, number, "defined">;
    }>>, Schemastery.ObjectT<NoInfer<{
      enabled: z<boolean, boolean, "defined">;
      debounceMs: z<number, number, "defined">;
      pushTimeoutMs: z<number, number, "defined">;
      maxBindingsPerRoom: z<number, number, "defined">;
      maxCandidates: z<number, number, "defined">;
    }>>, "defined">;
  }>>, Schemastery.ObjectT<NoInfer<{
    path: z<string, string, "defined">;
    tokenSecret: z<string, string, "plain">;
    maxFileSize: z<number, number, "defined">;
    chunkSize: z<number, number, "defined">;
    rooms: z<Schemastery.ObjectS<NoInfer<{
      maxRooms: z<number, number, "defined">;
      maxRoomsPerDevice: z<number, number, "defined">;
      maxMembersPerRoom: z<number, number, "defined">;
      roomCodeLength: z<number, number, "defined">;
      minPasswordLength: z<number, number, "defined">;
      maxJoinAttempts: z<number, number, "defined">;
      joinAttemptWindowMs: z<number, number, "defined">;
      joinLockoutMs: z<number, number, "defined">;
      ticketTtlMs: z<number, number, "defined">;
      idleTtlMs: z<number, number, "defined">;
      closeWhenOwnerLeaves: z<boolean, boolean, "defined">;
      discoverableByDefault: z<boolean, boolean, "defined">;
      allowRoomList: z<boolean, boolean, "defined">;
    }>>, Schemastery.ObjectT<NoInfer<{
      maxRooms: z<number, number, "defined">;
      maxRoomsPerDevice: z<number, number, "defined">;
      maxMembersPerRoom: z<number, number, "defined">;
      roomCodeLength: z<number, number, "defined">;
      minPasswordLength: z<number, number, "defined">;
      maxJoinAttempts: z<number, number, "defined">;
      joinAttemptWindowMs: z<number, number, "defined">;
      joinLockoutMs: z<number, number, "defined">;
      ticketTtlMs: z<number, number, "defined">;
      idleTtlMs: z<number, number, "defined">;
      closeWhenOwnerLeaves: z<boolean, boolean, "defined">;
      discoverableByDefault: z<boolean, boolean, "defined">;
      allowRoomList: z<boolean, boolean, "defined">;
    }>>, "defined">;
    roomGit: z<Schemastery.ObjectS<NoInfer<{
      enabled: z<boolean, boolean, "defined">;
      debounceMs: z<number, number, "defined">;
      pushTimeoutMs: z<number, number, "defined">;
      maxBindingsPerRoom: z<number, number, "defined">;
      maxCandidates: z<number, number, "defined">;
    }>>, Schemastery.ObjectT<NoInfer<{
      enabled: z<boolean, boolean, "defined">;
      debounceMs: z<number, number, "defined">;
      pushTimeoutMs: z<number, number, "defined">;
      maxBindingsPerRoom: z<number, number, "defined">;
      maxCandidates: z<number, number, "defined">;
    }>>, "defined">;
  }>>, "plain">;
  apply: typeof apply;
};
//#endregion
export { Config, CrossTransferConfig, DeviceInfo, RoomGateway, SessionInfo, apply, _default as default, inject, name };
//# sourceMappingURL=index.d.ts.map