import { Context, Service } from "@deepseek-ai/cordis";
import { z } from "zod";
import React from "react";

//#region src/rooms.d.ts

type RoomRole = 'owner' | 'member';
/** 房号：4~12 位纯数字字符串 */
type RoomId = string;
/** 设备身份凭据（256-bit hex）。客户端自存、服务端只认它，deviceId 由它派生 */

/**
 * 房间的公开投影。不含 sessionId、不含票据、不含任何凭据。
 * ownerDeviceId 在对外投影里必须脱敏（见 maskDeviceId），因为它不是凭据但也不该被枚举。
 */
interface RoomInfo {
  roomId: RoomId;
  name: string;
  /** 脱敏房主设备 id（前 4 + '…' + 后 4）。用于 UI 判断「我是不是房主」，不是授权依据 */
  ownerDeviceId: string;
  /** 房主当前是否有活会话 */
  ownerOnline: boolean;
  createdAt: number;
  lastActivityAt: number;
  /** 成员行数，含离线但保留席位的成员 */
  memberCount: number;
  maxMembers: number;
  locked: boolean;
  discoverable: boolean;
  /**
   * 房间是否已配置 Git 仓库（契约 §3）。
   * 公开投影只暴露这个布尔值，绝不暴露 URL、分支或凭据——仓库细节只经
   * RoomRepoStatus（脱敏后）流转，避免从房间列表/详情里泄漏远端地址。
   */
  repoConfigured: boolean;
}
/** 成员视图。deviceId 同样脱敏；sessionIds 集合永不外泄，只暴露计数与在线位。 */
interface RoomMember {
  deviceId: string;
  deviceName: string;
  role: RoomRole;
  joinedAt: number;
  sessionCount: number;
  online: boolean;
}
/** 票据的服务端记录 */
interface RoomTicket {
  ticket: string;
  roomId: RoomId;
  deviceId: string;
  role: RoomRole;
  issuedAt: number;
  expiresAt: number;
}
//#endregion
//#region src/client/CrossTransferClient.d.ts
interface CrossTransferClientConfig$1 {
  autoConnect?: boolean;
  deviceName?: string;
}
interface TransferSession {
  id: string;
  deviceId: string;
  deviceName: string;
  connectedAt: number;
}
interface PeerDevice {
  deviceId: string;
  deviceName: string;
  sessionCount: number;
  capabilities: string[];
}
interface WSMessage {
  type: string;
  sessionId?: string;
  deviceId?: string;
  fromDeviceId?: string;
  targetDeviceId?: string;
  payload?: unknown;
  messageId?: string;
}
interface FileTransferInfo {
  fileId: string;
  fileName: string;
  fileSize: number;
  mimeType: string;
  checksum: string;
  chunkCount: number;
  senderDeviceId: string;
  senderDeviceName: string;
  status: 'pending' | 'receiving' | 'complete' | 'failed' | 'cancelled';
  progress: number;
  receivedChunks: number;
}
interface ChatMessage {
  messageId: string;
  roomId: string;
  senderDeviceId: string;
  senderDeviceName: string;
  senderSessionId: string;
  content: string;
  type: 'text' | 'system' | 'file' | 'code';
  metadata?: Record<string, unknown>;
  timestamp: number;
  edited?: boolean;
  replyTo?: string;
}
interface RepoConfig {
  repoId: string;
  name: string;
  localPath: string;
  remoteUrl: string;
  branch: string;
  auth?: {
    type: 'token' | 'ssh';
    token?: string;
    username?: string;
  };
  autoSync?: boolean;
  syncInterval?: number;
}
interface SyncResult {
  success: boolean;
  operation: string;
  repoId: string;
  output?: string;
  error?: string;
  conflicts?: string[];
  filesChanged?: number;
  commitsAhead?: number;
  commitsBehind?: number;
}
/**
 * 房间仓库凭据（§3）。浏览器端只负责把用户填的令牌带过去，服务端保证不落盘；
 * 与 src/room-workspace.ts 的同名形状保持一致。
 */
interface RoomRepoAuthInput {
  /** 仅支持 token 形式（HTTPS Basic）。 */
  type: 'token';
  token: string;
  /** 默认 'oauth2'（GitHub）或 'git'。 */
  username?: string;
}
/** 房主建房/改配时提交的仓库配置（§3）。 */
interface RoomRepoConfigInput {
  /** 必须是 http:// 或 https://；允许内嵌 userinfo，会被抽取成 auth 并从存储值里剥离。 */
  remoteUrl: string;
  /** 默认 'main'。 */
  branch?: string;
  auth?: RoomRepoAuthInput;
  /** 默认 true。 */
  autoCommit?: boolean;
  /** 默认 true。 */
  autoPush?: boolean;
  commitAuthorName?: string;
  commitAuthorEmail?: string;
}
/** 对外投影：绝不包含 token、绝不包含未剥离 userinfo 的 URL（§3）。 */
interface RoomRepoStatus {
  roomId: string;
  configured: boolean;
  /** 已剥离 userinfo；未配置时省略。 */
  remoteUrl?: string;
  branch?: string;
  authConfigured: boolean;
  autoCommit: boolean;
  autoPush: boolean;
  updatedAt?: number;
  /** 脱敏。 */
  updatedByDeviceId?: string;
  bindings: WorkspaceBindingStatus[];
}
/** 单个成员的工作区绑定状态（§3）。 */
interface WorkspaceBindingStatus {
  /** 脱敏 deviceId。 */
  deviceId: string;
  deviceName: string;
  bound: boolean;
  /** 只对绑定者本人与房主返回真实路径；其他成员看到 undefined。 */
  workspacePath?: string;
  repoReady?: boolean;
  lastSync?: SyncSummary;
}
/** 一次同步（自动或手动）的结果（§3）。失败也必须可见，error 非空。 */
interface SyncSummary {
  at: number;
  ok: boolean;
  trigger: 'auto' | 'manual';
  /** 本次提交的文件数（含删除）。 */
  committed: number;
  commitOid?: string;
  pushed: boolean;
  error?: string;
}
/**
 * A failure the server described with a machine-readable code. The browser half
 * cannot reuse the host's RoomError (importing the class would pull node:crypto
 * into the bundle), so this mirrors it.
 */

/** A room this client is currently in, as it is entitled to be (ticket included). */
interface ActiveRoom {
  roomId: string;
  name: string;
  role: RoomRole;
  ticket: string;
  expiresAt: number;
}
interface CreateRoomOptions {
  roomId?: string;
  name?: string;
  password: string;
  maxMembers?: number;
  discoverable?: boolean;
  /** 建房时一并设置仓库（§5.1）；不传即「房主稍后配置」。 */
  repo?: RoomRepoConfigInput;
}
interface CrossTransferEvents {
  connected: [session: TransferSession];
  disconnected: [sessionId: string];
  message: [message: WSMessage];
  deviceList: [devices: PeerDevice[]];
  peerConnected: [peer: PeerDevice];
  peerDisconnected: [peer: PeerDevice];
  error: [error: Error];
  fileOffer: [info: FileTransferInfo, fromDeviceId: string];
  fileProgress: [fileId: string, progress: {
    received: number;
    total: number;
    percentage: number;
  }];
  fileComplete: [fileId: string, data: Uint8Array];
  fileError: [fileId: string, error: string];
  chatMessage: [message: ChatMessage];
  chatHistory: [messages: ChatMessage[]];
  chatUserJoined: [roomId: string, deviceId: string, deviceName: string];
  chatUserLeft: [roomId: string, deviceId: string];
  chatTyping: [roomId: string, deviceId: string, deviceName: string, isTyping: boolean];
  roomJoined: [room: ActiveRoom, member: RoomMember, ticket: RoomTicket];
  roomLeft: [roomId: string];
  roomList: [rooms: RoomInfo[]];
  roomMembers: [roomId: string, members: RoomMember[]];
  roomClosed: [roomId: string, reason: string];
  roomMemberKicked: [roomId: string, deviceId: string, kickedByDeviceId: string];
  roomLocked: [roomId: string, locked: boolean];
  roomPasswordChanged: [roomId: string];
  activeRoomChanged: [room: ActiveRoom | null];
  roomGitStatus: [status: RoomRepoStatus];
  roomGitSync: [roomId: string, deviceId: string, result: SyncSummary];
  syncProgress: [repoId: string, progress: {
    phase: string;
    loaded: number;
    total: number;
  }];
  syncComplete: [result: SyncResult];
  syncError: [repoId: string, error: string, operation: string];
  syncConflict: [repoId: string, conflicts: string[]];
  repoList: [repos: RepoConfig[]];
}
declare class CrossTransferClient extends Service {
  private ws;
  private session;
  private deviceId;
  private deviceSecret;
  private deviceName;
  private token;
  private serverUrl;
  private reconnectTimer;
  private pendingRequests;
  private messageIdCounter;
  private fileTransfers;
  private joinedRooms;
  /** Passwords live in memory only: a persisted one would outlive the session it gates. */
  private roomPasswords;
  private activeRoomId;
  private rejoinInFlight;
  /** Answered ticket re-issues, so one failure cannot spin into a rejoin loop. */
  private rejoinRetries;
  private emitter;
  constructor(ctx: Context, config: CrossTransferClientConfig$1);
  on<K extends keyof CrossTransferEvents>(event: K, listener: (...args: CrossTransferEvents[K]) => void): () => void;
  off<K extends keyof CrossTransferEvents>(event: K, listener: (...args: CrossTransferEvents[K]) => void): void;
  emit<K extends keyof CrossTransferEvents>(event: K, ...args: CrossTransferEvents[K]): void;
  once<K extends keyof CrossTransferEvents>(event: K, listener: (...args: CrossTransferEvents[K]) => void): () => void;
  private storage;
  private restoreDeviceSecret;
  /**
   * sha256('xfer-device:' + secret).slice(0,16), matching src/rooms.ts
   * deriveDeviceId. WebCrypto only: a node:crypto import would break the browser
   * bundle, and this value is a stable local handle, not the credential itself.
   */
  private computeDeviceId;
  /**
   * Ensure this browser holds a registered device identity. A stale secret the
   * host does not know (it restarted) is dropped and re-minted once — the
   * alternative is a device that can never connect again.
   */
  ensureDeviceRegistered(): Promise<void>;
  private registerDevice;
  /** Reply shape shared by the REST surface: { error: { code, message, retryAfterMs? } }. */
  private readJson;
  private describeHttpError;
  connect(serverUrl: string, token?: string): Promise<void>;
  private scheduleReconnect;
  private handleMessage;
  /**
   * Error frames arrive either as the legacy plain string or as an object with a
   * machine-readable code. Both must keep working; callers branch on `code`.
   */
  private toRequestError;
  /** `room-list` payloads are frames, so tolerate both `{rooms:[…]}` and a bare array. */
  private roomsFromPayload;
  private rememberRoom;
  private applyRoomLeft;
  private forgetRoom;
  /** A reply frame carries the same data a broadcast would; apply it without re-emitting. */
  private applyRoomReply;
  /**
   * 请求 type → 应答 type 的协议映射。客户端自己不发应答；这是请求/应答契约的
   * 参考实现，测试的 mock 服务端靠它造出与真实服务端一致的回帧。
   */
  private replyTypeFor;
  /**
   * 请求帧对应的应答 payload（契约参考实现，供测试的 mock 服务端使用）。
   * 字段取自请求本身，与 src/rooms.ts 的 RoomJoinResult/RoomLeaveResult 对齐；
   * 票据固定为 ticket-<房号>，expiresAt 用测试夹具同一时刻。
   */
  private replyPayloadFor;
  /**
   * Re-enter every room this client was in. Passwords are memory-only, so a page
   * reload loses them by design; a reconnect keeps them.
   */
  private rejoinRooms;
  /**
   * 房间操作的公共通道：invalid-ticket 时用内存里的密码自动重进一次再重试原操作；
   * 成功的应答则顺手检查本地票据视图，已过期就静默重签，省掉下一发的 401。
   */
  private roomRequest;
  /** 本地票据视图已过期（expiresAt 已过）：趁下一次操作前静默重签一次。 */
  private reissueIfTicketStale;
  /**
   * 票据失效后的唯一一次自动重进。有密码就重发 room-join 并返回 true；没密码或
   * 已有一笔重进在途时只上报错误（quiet 用于顺手重签：不值得为它喊一嗓子）。
   */
  private handleTicketExpired;
  private handleFileOffer;
  private handleFileChunk;
  private handleFileComplete;
  private flushPendingMessages;
  private generateMessageId;
  private send;
  private request;
  /** The HTTP base for this plugin's REST surface, derived from the WS URL. */
  private httpBase;
  /**
   * Trade this device's credentials for a host token. Called before every dial
   * because a host restart mints a new token secret. `tokenUrl` exists for the
   * first connect, which happens before `serverUrl` is set; legacy callers pass
   * the old `/token` path, which is normalized onto the contract's `/devices/token`.
   */
  fetchToken(tokenUrl?: string): Promise<string>;
  getToken(): string;
  fetchDevices(): Promise<PeerDevice[]>;
  getSession(): TransferSession | null;
  getDeviceId(): string;
  getDeviceName(): string;
  setDeviceName(name: string): void;
  isConnected(): boolean;
  disconnect(): void;
  /** Re-establish the connection from scratch, acquiring a fresh token first. */
  reconnect(): Promise<void>;
  sendFile(file: File, targetDeviceId: string): Promise<string>;
  cancelFile(fileId: string): void;
  createRoom(options: CreateRoomOptions): Promise<ActiveRoom>;
  joinRoom(roomId: string, password: string): Promise<ActiveRoom>;
  /** 无密码进房：仅当服务端仍认这个设备是成员（成员快速通道）时才会成功。 */
  enterRoom(roomId: string, password?: string): Promise<ActiveRoom>;
  leaveRoom(roomId: string): Promise<void>;
  closeRoom(roomId: string): Promise<void>;
  /** `deviceId` is the real id from the room-members response / a WS broadcast payload. */
  kickMember(roomId: string, deviceId: string): Promise<void>;
  changeRoomPassword(roomId: string, password: string): Promise<void>;
  setRoomLocked(roomId: string, locked: boolean): Promise<void>;
  listRooms(): Promise<RoomInfo[]>;
  requestRoomMembers(roomId: string): Promise<RoomMember[]>;
  sendChatMessage(roomId: string, content: string, type?: 'text' | 'code' | 'file', metadata?: Record<string, unknown>): Promise<ChatMessage>;
  requestChatHistory(roomId: string, limit?: number): void;
  setTyping(roomId: string, isTyping: boolean): void;
  getJoinedRooms(): ActiveRoom[];
  getActiveRoom(): ActiveRoom | null;
  getRoomPassword(roomId: string): string | null;
  setActiveRoom(roomId: string): void;
  setRoomGit(roomId: string, repo: RoomRepoConfigInput): Promise<RoomRepoStatus>;
  clearRoomGit(roomId: string): Promise<RoomRepoStatus>;
  getRoomGitStatus(roomId: string): Promise<RoomRepoStatus>;
  bindRoomWorkspace(roomId: string, path: string): Promise<RoomRepoStatus>;
  unbindRoomWorkspace(roomId: string): Promise<RoomRepoStatus>;
  listWorkspaceCandidates(roomId: string): Promise<string[]>;
  syncRoomGit(roomId: string): Promise<SyncSummary>;
  registerRepo(config: Omit<RepoConfig, 'repoId'>): Promise<RepoConfig>;
  syncRepo(repoId: string, operation: 'fetch' | 'pull' | 'push' | 'status', options?: Partial<{
    remote: string;
    branch: string;
    force: boolean;
  }>): Promise<SyncResult>;
  requestRepoList(): void;
  createOffer(targetDeviceId: string): Promise<RTCSessionDescriptionInit>;
  createAnswer(targetDeviceId: string, offer: RTCSessionDescriptionInit): Promise<RTCSessionDescriptionInit>;
  addIceCandidate(targetDeviceId: string, candidate: RTCIceCandidateInit): void;
}
//# sourceMappingURL=CrossTransferClient.d.ts.map
//#endregion
//#region src/client/FileTransferPanel.d.ts
interface FileTransferPanelProps {
  client: CrossTransferClient;
}
declare const FileTransferPanel: React.FC<FileTransferPanelProps>;
//#endregion
//#region src/client/ChatPanel.d.ts
interface ChatPanelProps {
  client: CrossTransferClient;
  /** 没进房时的引导去向：由 UI 外壳负责切页签，面板自己不碰标签状态。 */
  onRequireRooms?: () => void;
}
/**
 * 聊天必须进房才能用。房间来源只有一个：客户端「已进入的房间」列表 ——
 * 旧实现自己维护房间数组并自动加入 `default`，服务端根本没有那些房间。
 */
declare const ChatPanel: React.FC<ChatPanelProps>;
//#endregion
//#region src/client/RoomPanel.d.ts
interface RoomPanelProps {
  client: CrossTransferClient;
}
/**
 * 房间面板：建房、进房、房间列表、成员与房主操作。
 *
 * 密码/哈希在这个面板里只以「输入」形态存在 —— 输入框 type=password，且没有任何
 * 把密码写进列表或成员视图的代码路径；确认密码只在本地比对，不上行。
 */
declare const RoomPanel: React.FC<RoomPanelProps>;
//#endregion
//#region src/client/GitSyncPanel.d.ts
interface GitSyncPanelProps {
  client: CrossTransferClient;
}
declare const GitSyncPanel: React.FC<GitSyncPanelProps>;
//#endregion
//#region src/client/DeviceList.d.ts
interface DeviceListProps {
  client: CrossTransferClient;
  onDeviceSelect?: (device: PeerDevice) => void;
}
declare const DeviceList: React.FC<DeviceListProps>;
//#endregion
//#region src/client/CrossTransferUI.d.ts
interface CrossTransferUIProps {
  client: CrossTransferClient;
}
declare const CrossTransferUI: React.FC<CrossTransferUIProps>;
//#endregion
//#region src/client/index.d.ts
/** Cordis plugin name. */
declare const name = "cross-transfer-client";
/**
 * Client services this half composes with. `slots` is the renderer's slot
 * registry (a cordis service, not a package to prefetch), so it belongs here
 * rather than in `dsh.client.inject`.
 */
declare const inject: string[];
interface CrossTransferClientConfig {
  autoConnect?: boolean;
  deviceName?: string;
}
/**
 * A boot entry carries no config row, so the harness validates this schema
 * against `undefined` — a bare object schema rejects that with "expected
 * object, received undefined" and the whole plugin fails to load. `prefault`
 * supplies `{}` as the input in that case and then applies the inner defaults,
 * so an unconfigured plugin still sees `autoConnect: true`.
 *
 * The harness's own client plugins avoid this entirely by exporting no Config;
 * this half keeps one so the two switches stay settable in a config row.
 */
declare const Config: z.ZodPrefault<z.ZodObject<{
  autoConnect: z.ZodDefault<z.ZodBoolean>;
  deviceName: z.ZodOptional<z.ZodString>;
}, z.core.$strip>>;
/**
 * Provide the client service; auto-connect once the host generation is ready.
 * @param ctx - client plugin context.
 * @param config - validated client configuration.
 */
declare function apply(ctx: Context, config: CrossTransferClientConfig): void;
declare const _default: {
  name: string;
  inject: string[];
  Config: z.ZodPrefault<z.ZodObject<{
    autoConnect: z.ZodDefault<z.ZodBoolean>;
    deviceName: z.ZodOptional<z.ZodString>;
  }, z.core.$strip>>;
  apply: typeof apply;
};
//#endregion
export { ChatPanel, Config, CrossTransferClient, CrossTransferClientConfig, CrossTransferUI, DeviceList, FileTransferPanel, GitSyncPanel, RoomPanel, apply, _default as default, inject, name };
//# sourceMappingURL=index.d.cts.map